__version__ = "0.0.1"

def system():
    return 'There is a theory which states that if ever anyone discovers exactly what the Screenwriter is for and why it is here, ' \
           'it will instantly disappear and be replaced by something even more bizarre and inexplicable. ' \
           'There is another theory which states that this has already happened.'

if __name__ == '__main__':
    pass
