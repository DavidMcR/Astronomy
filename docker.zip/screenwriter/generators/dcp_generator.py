"""
Random DCP Generator
"""
import json
import uuid
import os
import random
import base64
import hashlib
import shutil
import movienamegen

# Content
CONTENT_TYPE_WEIGHTS = ["ftr", "ftr", "ftr", "ftr", "trl", "trl", "adv"]
CONTENT_TYPES = {
    "ftr": {
        "text": "feature",
        "min_duration": 60 * 60 * 1,
        "max_duration": 60 * 60 * 2,
    },
    "adv": {
        "text": "advertisement",
        "min_duration": 20,
        "max_duration": 60,
    },
    "trl": {
        "text": "trailer",
        "min_duration": 60,
        "max_duration": 180,
    }
}
ASSET_CPL_MAP = {}

def find_root_dcps(root_folder):
    dcps = []
    for root, dirs, files in os.walk(root_folder):
        for dir in dirs:
            ignore_this = False
            for ignore in ["asset", "cpl", "ingest"]:
                if ignore in dir.lower():
                    ignore_this = True
            if not ignore_this:
                dcps.append({"path": os.path.join(root, dir), "name": dir})
    return dcps

def create_new_dcps(dcps, count, ingest_folder):
    """
    Create [count] DCPs and copy to [dump]
    """
    for i in xrange(0, count):
        # Pick a DCP and copy it to the dump dir
        to_process = random.choice(dcps)
        root_dcp = os.path.join(ingest_folder, to_process["name"])
        shutil.copytree(to_process["path"], root_dcp)

        # Convert that root DCP to a new DCP
        convert_root_dcp(root_dcp, to_process["name"])

def convert_root_dcp(target, old_cpl_uuid):
    """
    Convert a root DCP to a "new" DCP
    * All we are doing here is changing the UUIDs of everything and the name of the CPL
    """

    # Rename root
    new_cpl_uuid = str(uuid.uuid4())
    new_target = target.replace(old_cpl_uuid, new_cpl_uuid)
    os.rename(target, new_target)

    # Pick a type and duration
    content_type_key = random.choice(CONTENT_TYPE_WEIGHTS)
    content_type_text = CONTENT_TYPES[content_type_key]["text"]
    content_duration = random.randrange(
        CONTENT_TYPES[content_type_key]["min_duration"] * 24,
        CONTENT_TYPES[content_type_key]["max_duration"] * 24
    )

    # What we want to replace
    old_content_type = "advertisement" # currently in the CPL xml
    old_content_duration = 119 # currently in the CPL xml

    # Segregate
    assets = []
    not_assets = []
    for root, dirs, files in os.walk(new_target):
        for file in files:
            file_object = {"path": os.path.join(root, file), "name": file.split(".")[0], "filename": file}
            if is_asset(file.lower()):
                assets.append(file_object)
            else:
                not_assets.append(file_object)

            # Rename the CPL file and update any references to the CPL UUID
            if old_cpl_uuid in file_object["filename"]:
                data = ""
                with open(file_object["path"], "r") as cpl_file:
                    for line in cpl_file:
                        data += line
                        if "annotationtext" in line.lower():
                            old_name = line.replace(" ", "").split(">")[1].split("</")[0]

                old_cpl_hash = file_hash(file_object["path"])
                old_cpl_size = str(os.path.getsize(file_object["path"]))
                new_cpl_filepath = file_object["path"].replace(old_cpl_uuid, new_cpl_uuid)
                os.rename(file_object["path"], new_cpl_filepath)
                find_and_replace_walk(old_cpl_uuid, new_cpl_uuid, root)
                find_and_replace_walk(str(old_content_duration), str(content_duration), root, ignore=["pkl", "vol", "asset", "mxf"])
                find_and_replace_walk(old_content_type, content_type_text, root, ignore=["pkl", "vol", "asset", "mxf"])

    # Replace asset UUIDs
    for asset in assets:
        new_uuid = str(uuid.uuid4())
        old_uuid = asset["name"]
        new_asset_path = asset["path"].replace(old_uuid, new_uuid)
        os.rename(asset["path"], new_asset_path)
        find_and_replace_walk(old_uuid, new_uuid, root)
        global ASSET_CPL_MAP
        ASSET_CPL_MAP[new_uuid] = new_cpl_uuid

    # Rename
    new_name = generate_content_title_text(content_type_key)
    find_and_replace_walk(old_name, new_name, root)

    # Validate CPL Size
    new_cpl_size = str(os.path.getsize(new_cpl_filepath))
    new_cpl_hash = file_hash(new_cpl_filepath)
    find_and_replace_walk(old_cpl_hash, new_cpl_hash, root)
    find_and_replace_walk(old_cpl_size, new_cpl_size, root)

def is_asset(filename):
    """
    Is this file an asset?
    """
    return not "xml" in filename and not "assetmap" in filename and not "volindex" in filename

def is_cpl(filename):
    """
    Is the file a CPL? Assuming it's named after it's uuid...
    """
    return "xml" in filename and len(filename) == 40

def file_hash(path):
    """
    Return SHA1 hash for file
    """
    buffer_size = 100
    file_object = open(path, "rb")
    chunk = file_object.read(buffer_size)
    hash_object = hashlib.sha1(chunk)
    while file_object:
        chunk = file_object.read(buffer_size)
        if not chunk:
            break
        hash_object.update(chunk)
    return base64.encodestring(hash_object.digest()).strip()

def generate_content_title_text(type):
    """
    Generate content title text
    """
    ctt = movienamegen.generate().replace(" ", "-").upper() # Title
    ctt += "_" + type.upper() # Type
    ctt += "_" + random.choice(["F", "S"]) # Aspect Ratio
    ctt += "_" + random.choice(["EN-XX", "EN-DE", "EN-NL", "EN-EN", "EN-JA", "EN-NO"]) # Subs
    ctt += "_" + random.choice(["INT", "XX"]) # Territory
    ctt += "_" + random.choice(["51", "71", "71-HI"]) # Audio
    ctt += "_" + random.choice(["2K"]) # Res
    ctt += "_" + random.choice(["AAM"]) # Facility
    ctt += "_" + random.choice(["20100203_AAM_OV", "20100203_AAM_VF"]) # Rest
    return ctt

def find_and_replace_walk(old, new, root_dir, ignore=[]):
    """
    Walk through all files in directory and replace the given string
    """
    for root, dirs, files in os.walk(root_dir):
        for file in files:
            filename = os.path.join(root, file).lower()
            if not is_asset(filename):
                if not [ignored for ignored in ignore if ignored in filename]:
                    find_and_replace(old, new, os.path.join(root, file))

def extract(evaluator, info_json_creator, dump, ingest_folder):
    """
    Extract files that are evaluated by the evaluator and dump them in the dump and then create info json
    """
    for root, dirs, files in os.walk(ingest_folder):
        for f in files:
            if evaluator(f.lower()):
                dump_dir = os.path.join(dump, f[0:36])
                if not os.path.exists(dump_dir):
                    os.mkdir(dump_dir)
                target_file = os.path.join(root, f)
                shutil.copy2(target_file, dump_dir)
                info_json = os.path.join(dump_dir, "INFO.json")
                with open(info_json, "w") as info_json_file:
                    info_json_file.write(json.dumps(info_json_creator(f, target_file)))

def create_cpl_info_json(filename, path):
    return {
        "mimetype": "text/xml;asdcpKind=CPL",
        "create_date": 1423413862.7379999,
        "cpl_uuid": filename[0:36],
        "generated_hash": file_hash(path),
        "hash": file_hash(path),
        "ingest_source_type": "watchfolder",
        "size": int(os.path.getsize(path))
    }

def create_asset_info_json(filename, path):
    return {
        "mimetype": "application/x-smpte-mxf;asdcpKind=Picture",
        "create_date": 1423412559.1889999,
        "cpl_uuid": ASSET_CPL_MAP[filename[0:36]],
        "generated_hash": file_hash(path),
        "hash": file_hash(path),
        "size": int(os.path.getsize(path))
    }

def setup_dirs(cpl_folder, asset_folder, ingest_folder):
    if cpl_folder:
        global CPL_FOLDER
        CPL_FOLDER = cpl_folder
    if asset_folder:
        global ASSET_FOLDER
        ASSET_FOLDER = asset_folder
    if os.path.exists(ingest_folder):
        shutil.rmtree(ingest_folder)
    for d in [CPL_FOLDER, ASSET_FOLDER, ingest_folder]:
        if not os.path.exists(d):
            os.mkdir(d)

def find_and_replace(old, new, file_path):
    """
    Find and replace instances of given string in file
    """
    contents = ""
    with open(file_path, "r") as target:
        contents += target.read()

    contents = contents.replace(old, new)
    with open(file_path, "w") as target:
        target.write(contents)

def generate(count, cpl_folder, asset_folder, ingest_folder, root_folder):
    if not os.path.exists(root_folder):
        raise Exception("Input folder [%s] doesn't exist. Create it and add a DCP, generator needs a DCP to base new ones off of" % str(root_folder))
    setup_dirs(cpl_folder, asset_folder, ingest_folder)
    create_new_dcps(find_root_dcps(root_folder), count, ingest_folder)
    extract(is_asset, create_asset_info_json, asset_folder, ingest_folder)
    extract(is_cpl, create_cpl_info_json, cpl_folder, ingest_folder)

if __name__ == "__main__":
    root = os.getcwd()
    generate(10,
        os.path.join(root, "CPL"),
        os.path.join(root, "ASSET"),
        os.path.join(root, "INGEST"),
        root
    )